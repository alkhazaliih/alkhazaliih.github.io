/*
 * Vencord, a Discord client mod
 * Simple plugin that runs a Quest helper script
 * when a configurable keybind is pressed.
 * 
 * Author: Dax
 * Version: 1.0.0
 * Date: 2026-02-06
 * Description: Simple plugin that runs a Quest helper script
 * when a configurable keybind is pressed.
 * supports all tasks and works in browser and desktop app.
 * shows progress and completion status.
 * support: https://discord.gg/9ravwb3WHM
 * Repository: https://github.com/Alkhazalih/QuestSpoofer
 * Issue tracker: https://github.com/Alkhazalih/QuestSpoofer/issues
 * 
 * Drop this file into your Vencord plugins folder
 * and enable it from the plugins tab.
 */

import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType, StartAt } from "@utils/types";

const settings = definePluginSettings({
    hotkey: {
        type: OptionType.STRING,
        description: "Keyboard key to start Quest spoof (e.g. F8, q, Q)",
        default: "F8"
    }
});

type StatusKind = "info" | "progress" | "success" | "error";

let statusContainer: HTMLDivElement | null = null;
let hideTimeout: number | null = null;

function ensureStatusContainer() {
    if (statusContainer && document.body.contains(statusContainer)) return statusContainer;

    statusContainer = document.createElement("div");
    statusContainer.style.position = "fixed";
    statusContainer.style.top = "16px";
    statusContainer.style.right = "16px";
    statusContainer.style.zIndex = "9999";
    statusContainer.style.minWidth = "260px";
    statusContainer.style.maxWidth = "320px";
    statusContainer.style.padding = "10px 14px";
    statusContainer.style.borderRadius = "8px";
    statusContainer.style.backgroundColor = "rgba(32, 34, 37, 0.95)";
    statusContainer.style.color = "#fff";
    statusContainer.style.fontSize = "13px";
    statusContainer.style.boxShadow = "0 4px 12px rgba(0,0,0,0.6)";
    statusContainer.style.pointerEvents = "none";
    statusContainer.style.display = "none";

    const titleEl = document.createElement("div");
    titleEl.dataset["qhRole"] = "title";
    titleEl.style.fontWeight = "600";
    titleEl.style.marginBottom = "4px";
    statusContainer.appendChild(titleEl);

    const bodyEl = document.createElement("div");
    bodyEl.dataset["qhRole"] = "body";
    statusContainer.appendChild(bodyEl);

    document.body.appendChild(statusContainer);
    return statusContainer;
}

function hideStatus() {
    if (!statusContainer) return;
    statusContainer.style.display = "none";
}

function showStatus(kind: StatusKind, title: string, body: string, autoHideMs: number | null = 3500) {
    const el = ensureStatusContainer();
    const titleEl = el.querySelector<HTMLDivElement>("div[data-qh-role='title']");
    const bodyEl = el.querySelector<HTMLDivElement>("div[data-qh-role='body']");

    if (!titleEl || !bodyEl) return;

    // Colors per kind
    if (kind === "success") {
        el.style.border = "1px solid #23a559";
    } else if (kind === "error") {
        el.style.border = "1px solid #f04747";
    } else if (kind === "progress") {
        el.style.border = "1px solid #5865f2";
    } else {
        el.style.border = "1px solid rgba(255,255,255,0.2)";
    }

    titleEl.textContent = title;
    bodyEl.textContent = body;
    el.style.display = "block";

    if (hideTimeout != null) {
        window.clearTimeout(hideTimeout);
        hideTimeout = null;
    }

    if (autoHideMs != null && kind !== "progress") {
        hideTimeout = window.setTimeout(() => {
            hideStatus();
        }, autoHideMs);
    }
}

function runQuestSpoofer() {
    try {
        showStatus("info", "QuestHotkey", "Starting quest spoof...");
        // Original script, wrapped in a function so it can be triggered on demand.
        // Slightly reformatted for TypeScript, but logic is unchanged.

        // @ts-ignore
        delete (window as any).$;

        // @ts-ignore
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const wpRequire = (window as any).webpackChunkdiscord_app.push([[Symbol()], {}, (r: any) => r]);
        // @ts-ignore
        (window as any).webpackChunkdiscord_app.pop();

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let ApplicationStreamingStore: any = Object.values(wpRequire.c).find(
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            (x: any) => x?.exports?.Z?.__proto__?.getStreamerActiveStreamMetadata
        )?.exports?.Z;

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let RunningGameStore: any,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            QuestsStore: any,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            ChannelStore: any,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            GuildChannelStore: any,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            FluxDispatcher: any,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            api: any;

        if (!ApplicationStreamingStore) {
            ApplicationStreamingStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.A?.__proto__?.getStreamerActiveStreamMetadata
            ).exports.A;

            RunningGameStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.Ay?.getRunningGames
            ).exports.Ay;

            QuestsStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.A?.__proto__?.getQuest
            ).exports.A;

            ChannelStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.A?.__proto__?.getAllThreadsForParent
            ).exports.A;

            GuildChannelStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.Ay?.getSFWDefaultChannel
            ).exports.Ay;

            FluxDispatcher = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.h?.__proto__?.flushWaitQueue
            ).exports.h;

            api = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.Bo?.get
            ).exports.Bo;
        } else {
            RunningGameStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.ZP?.getRunningGames
            ).exports.ZP;

            QuestsStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.Z?.__proto__?.getQuest
            ).exports.Z;

            ChannelStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.Z?.__proto__?.getAllThreadsForParent
            ).exports.Z;

            GuildChannelStore = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.ZP?.getSFWDefaultChannel
            ).exports.ZP;

            FluxDispatcher = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.Z?.__proto__?.flushWaitQueue
            ).exports.Z;

            api = Object.values(wpRequire.c).find(
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (x: any) => x?.exports?.tn?.get
            ).exports.tn;
        }

        const supportedTasks = ["WATCH_VIDEO", "PLAY_ON_DESKTOP", "STREAM_ON_DESKTOP", "PLAY_ACTIVITY", "WATCH_VIDEO_ON_MOBILE"];

        const quests = [...QuestsStore.quests.values()].filter((x: any) =>
            x.userStatus?.enrolledAt &&
            !x.userStatus?.completedAt &&
            new Date(x.config.expiresAt).getTime() > Date.now() &&
            supportedTasks.find(y => Object.keys((x.config.taskConfig ?? x.config.taskConfigV2).tasks).includes(y))
        );

        const isApp = typeof (window as any).DiscordNative !== "undefined";

        if (quests.length === 0) {
            const msg = "You don't have any uncompleted quests!";
            console.log(msg);
            showStatus("info", "QuestHotkey", msg);
            return;
        }

        const doJob = function () {
            const quest = quests.pop();
            if (!quest) return;

            const pid = Math.floor(Math.random() * 30000) + 1000;

            const applicationId = quest.config.application.id;
            const applicationName = quest.config.application.name;
            const questName = quest.config.messages.questName;
            const taskConfig = quest.config.taskConfig ?? quest.config.taskConfigV2;
            const taskName = supportedTasks.find(x => taskConfig.tasks[x] != null)!;
            const secondsNeeded = taskConfig.tasks[taskName].target;
            let secondsDone = quest.userStatus?.progress?.[taskName]?.value ?? 0;

            if (taskName === "WATCH_VIDEO" || taskName === "WATCH_VIDEO_ON_MOBILE") {
                const maxFuture = 10, speed = 7, interval = 1;
                const enrolledAt = new Date(quest.userStatus.enrolledAt).getTime();
                let completed = false;

                const fn = async () => {
                    while (true) {
                        const maxAllowed = Math.floor((Date.now() - enrolledAt) / 1000) + maxFuture;
                        const diff = maxAllowed - secondsDone;
                        const timestamp = secondsDone + speed;

                        if (diff >= speed) {
                            const res = await api.post({
                                url: `/quests/${quest.id}/video-progress`,
                                body: { timestamp: Math.min(secondsNeeded, timestamp + Math.random()) }
                            });
                            completed = res.body.completed_at != null;
                            secondsDone = Math.min(secondsNeeded, timestamp);
                            const percent = Math.floor((secondsDone / secondsNeeded) * 100);
                            showStatus("progress", "Quest video progress", `${questName}: ${percent}%`);
                        }

                        if (timestamp >= secondsNeeded) {
                            break;
                        }
                        await new Promise(resolve => setTimeout(resolve, interval * 1000));
                    }

                    if (!completed) {
                        await api.post({
                            url: `/quests/${quest.id}/video-progress`,
                            body: { timestamp: secondsNeeded }
                        });
                    }
                    console.log("Quest completed!");
                    showStatus("success", "Quest completed", questName);
                    doJob();
                };

                fn();
                const msg = `Spoofing video for ${questName}.`;
                console.log(msg);
                showStatus("info", "QuestHotkey", msg);
            } else if (taskName === "PLAY_ON_DESKTOP") {
                if (!isApp) {
                    const msg = "This no longer works in browser for non-video quests. Use the discord desktop app to complete the " + questName + " quest!";
                    console.log(msg);
                    showStatus("error", "QuestHotkey", msg);
                } else {
                    api.get({ url: `/applications/public?application_ids=${applicationId}` }).then((res: any) => {
                        const appData = res.body[0];
                        const exeName = appData.executables.find((x: any) => x.os === "win32").name.replace(">", "");

                        const fakeGame = {
                            cmdLine: `C:\\\\Program Files\\\\${appData.name}\\\\${exeName}`,
                            exeName,
                            exePath: `c:/program files/${appData.name.toLowerCase()}/${exeName}`,
                            hidden: false,
                            isLauncher: false,
                            id: applicationId,
                            name: appData.name,
                            pid: pid,
                            pidPath: [pid],
                            processName: appData.name,
                            start: Date.now()
                        };

                        const realGames = RunningGameStore.getRunningGames();
                        const fakeGames = [fakeGame];
                        const realGetRunningGames = RunningGameStore.getRunningGames;
                        const realGetGameForPID = RunningGameStore.getGameForPID;
                        RunningGameStore.getRunningGames = () => fakeGames;
                        RunningGameStore.getGameForPID = (pidArg: number) => fakeGames.find((x: any) => x.pid === pidArg);
                        FluxDispatcher.dispatch({ type: "RUNNING_GAMES_CHANGE", removed: realGames, added: [fakeGame], games: fakeGames });

                        const fn = (data: any) => {
                            const progress = quest.config.configVersion === 1
                                ? data.userStatus.streamProgressSeconds
                                : Math.floor(data.userStatus.progress.PLAY_ON_DESKTOP.value);
                            console.log(`Quest progress: ${progress}/${secondsNeeded}`);
                            const percent = Math.floor((progress / secondsNeeded) * 100);
                            showStatus("progress", "Quest progress", `${questName}: ${percent}%`);

                            if (progress >= secondsNeeded) {
                                console.log("Quest completed!");
                                showStatus("success", "Quest completed", questName);

                                RunningGameStore.getRunningGames = realGetRunningGames;
                                RunningGameStore.getGameForPID = realGetGameForPID;
                                FluxDispatcher.dispatch({ type: "RUNNING_GAMES_CHANGE", removed: [fakeGame], added: [], games: [] });
                                FluxDispatcher.unsubscribe("QUESTS_SEND_HEARTBEAT_SUCCESS", fn);

                                doJob();
                            }
                        };

                        FluxDispatcher.subscribe("QUESTS_SEND_HEARTBEAT_SUCCESS", fn);

                        const msg = `Spoofed your game to ${applicationName}. Wait for ${Math.ceil((secondsNeeded - secondsDone) / 60)} more minutes.`;
                        console.log(msg);
                        showStatus("info", "QuestHotkey", msg);
                    });
                }
            } else if (taskName === "STREAM_ON_DESKTOP") {
                if (!isApp) {
                    const msg = "This no longer works in browser for non-video quests. Use the discord desktop app to complete the " + questName + " quest!";
                    console.log(msg);
                    showStatus("error", "QuestHotkey", msg);
                } else {
                    const realFunc = ApplicationStreamingStore.getStreamerActiveStreamMetadata;
                    ApplicationStreamingStore.getStreamerActiveStreamMetadata = () => ({
                        id: applicationId,
                        pid,
                        sourceName: null
                    });

                    const fn = (data: any) => {
                        const progress = quest.config.configVersion === 1
                            ? data.userStatus.streamProgressSeconds
                            : Math.floor(data.userStatus.progress.STREAM_ON_DESKTOP.value);
                        console.log(`Quest progress: ${progress}/${secondsNeeded}`);
                        const percent = Math.floor((progress / secondsNeeded) * 100);
                        showStatus("progress", "Quest progress", `${questName}: ${percent}%`);

                        if (progress >= secondsNeeded) {
                            console.log("Quest completed!");
                            showStatus("success", "Quest completed", questName);

                            ApplicationStreamingStore.getStreamerActiveStreamMetadata = realFunc;
                            FluxDispatcher.unsubscribe("QUESTS_SEND_HEARTBEAT_SUCCESS", fn);

                            doJob();
                        }
                    };

                    FluxDispatcher.subscribe("QUESTS_SEND_HEARTBEAT_SUCCESS", fn);

                    const msg1 = `Spoofed your stream to ${applicationName}. Stream any window in vc for ${Math.ceil((secondsNeeded - secondsDone) / 60)} more minutes.`;
                    const msg2 = "Remember that you need at least 1 other person to be in the vc!";
                    console.log(msg1);
                    console.log(msg2);
                    showStatus("info", "QuestHotkey", `${msg1} ${msg2}`);
                }
            } else if (taskName === "PLAY_ACTIVITY") {
                const channelId =
                    ChannelStore.getSortedPrivateChannels()[0]?.id ??
                    Object.values(GuildChannelStore.getAllGuilds()).find((x: any) => x != null && x.VOCAL.length > 0).VOCAL[0].channel.id;
                const streamKey = `call:${channelId}:1`;

                const fn = async () => {
                    console.log("Completing quest", questName, "-", quest.config.messages.questName);

                    while (true) {
                        const res = await api.post({
                            url: `/quests/${quest.id}/heartbeat`,
                            body: { stream_key: streamKey, terminal: false }
                        });
                        const progress = res.body.progress.PLAY_ACTIVITY.value;
                        console.log(`Quest progress: ${progress}/${secondsNeeded}`);
                        const percent = Math.floor((progress / secondsNeeded) * 100);
                        showStatus("progress", "Quest progress", `${questName}: ${percent}%`);

                        await new Promise(resolve => setTimeout(resolve, 20 * 1000));

                        if (progress >= secondsNeeded) {
                            await api.post({
                                url: `/quests/${quest.id}/heartbeat`,
                                body: { stream_key: streamKey, terminal: true }
                            });
                            break;
                        }
                    }

                    console.log("Quest completed!");
                    showStatus("success", "Quest completed", questName);
                    doJob();
                };

                fn();
            }
        };
        doJob();
    } catch (e) {
        console.error("[QuestHotkey] Error while running quest spoofer:", e);
        showStatus("error", "QuestHotkey error", String(e));
    }
}

let keyHandler: ((e: KeyboardEvent) => void) | null = null;

export default definePlugin({
    name: "QuestHotkey",
    description: "Runs the Quest spoofing script when you press a key (default: F8) while on the Quests page.",
    authors: [{ name: "Dax", id: 1142824627001888820 }],
    settings,
    startAt: StartAt.Loaded,

    start() {
        const getKey = () => this.settings.store.hotkey.toLowerCase();

        keyHandler = (e: KeyboardEvent) => {
            try {
                if (e.key.toLowerCase() === getKey()) {
                    console.log("[QuestHotkey] Triggered, running quest script...");
                    showStatus("info", "QuestHotkey", "Key pressed, starting quests...");
                    runQuestSpoofer();
                }
            } catch (err) {
                console.error("[QuestHotkey] Key handler error:", err);
            }
        };

        window.addEventListener("keydown", keyHandler);
        console.log("[QuestHotkey] Loaded. Press", this.settings.store.hotkey, "to start quests spoof.");
    },

    stop() {
        if (keyHandler) {
            window.removeEventListener("keydown", keyHandler);
            keyHandler = null;
        }
        console.log("[QuestHotkey] Unloaded.");
    }
});

